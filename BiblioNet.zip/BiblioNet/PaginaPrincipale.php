<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagina Principale</title>
    <link rel="stylesheet" href="./Stile.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
</head>

<body>

    <nav>
        <button> 
            <a href="./RegistrazioneAccesso.php">Registrati oppure Accedi</a> 
        </button>

        <button> 
            <a href="./Catalogo.php">Consulta il catalogo</a> 
        </button>

        <button> 
            <a href="./ChiSiamo.php">Chi siamo</a>
        </button>
    </nav>

    <div class="Sfondo-Presentazione">
        <h1>BiblioNet</h1>
        <h3>"Un archivio grande come il mondo"</h3>

        <h3>Accedi a migliaia di manoscritti, trattati e documenti storici provenienti dagli archivi dei più antichi regni, imperi e repubbliche.</h3>
        
        <button id="Esplora-Archivio">Prova Uno</button>
        <button>Prova Due</button>
    </div>

    <div>
        <p>
            Testo di Prova
        </p>
    </div>

    <div class="Sfondo-Presentazione">
        <p>
            Testo di Prova
        </p>
    </div>

    <div>
        <p>
            Testo di Prova
        </p>
    </div>

    <div class="Sfondo-Presentazione">
        <p>
            Testo di Prova
        </p>
    </div>
</body>
</html>