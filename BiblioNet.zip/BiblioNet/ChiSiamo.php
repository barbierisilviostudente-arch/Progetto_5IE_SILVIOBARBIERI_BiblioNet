<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi Siamo</title>
    <link rel="stylesheet" href="./Stile.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
</head>

<body class="Sfondo-Presentazione">

<nav>
        <button> 
            <a href="./RegistrazioneAccesso.php">Registrati oppure Accedi</a> 
        </button>

        <button> 
            <a href="./PaginaPrincipale.php">Torna all'inizio</a>
        </button>

        <button> 
            <a href="./Catalogo.php">Consulta il catalogo</a> 
        </button>        
</nav>
    
</body>

</html>